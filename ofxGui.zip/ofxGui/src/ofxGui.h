#pragma once

#include "ofxToggle.h"
#include "ofxSlider.h"
#include "ofxPanel.h"
#include "ofxButton.h"
#include "ofxLabel.h"
